# Kotlin-ListView
ListView Example with custom Adapter Using Kotlin in Android Studio

### Steps to follow :
Build ListView with Custom Adapter in Kotlin

1. Add listview

2. Create your model

3. Create row layout

4. Create adapter class

5. Combine all together

### Screenshot :

![screenshot_1537378114](https://user-images.githubusercontent.com/10756609/45770555-51cbe780-bc60-11e8-97d4-e3854b4da66d.png)

### Contact:

Drop me an email if you want to discuss anything further
